package Uninter;

import java.util.ArrayList;

public class Principal {

	public static void main (String [] args) {
		
		//chamar o menu principal
		Menu menu = new Menu();
		menu.exibirMenuPrincipal();

	}

}
