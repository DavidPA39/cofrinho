package Uninter;

import java.util.Scanner;

public class Menu {
	
	private Scanner sc;
	private Cofrinho cofrinho;
	
	public Menu (){
		sc = new Scanner(System.in);
		cofrinho = new Cofrinho();
	}
	
	// menu principal
	
	public void exibirMenuPrincipal() {
		System.out.println("COFRINHO:");
		System.out.println("1-Adicionar Moeda:");
		System.out.println("2-Remover Moeda:");
		System.out.println("3-Listar Moedas:");
		System.out.println("4-Calcular total convertido para Real:");
		System.out.println("0-Encerrar:");
		
		String opcaoSelecionada = sc.next();
		
		switch (opcaoSelecionada) {
		
		case "0":
			
			System.out.println("Sistema finalizado!");
			break;
			
		case "1":
			AdicionarMoedas();
			exibirMenuPrincipal();
			

			break;
		case "2":
			
			RemoverMoedas();
			exibirMenuPrincipal();

			break;
			
		
			
		case "3":
			
			cofrinho.listagemMoedas();
			exibirMenuPrincipal();

			break;
			
		case "4":
			double valorTotalConvertido = cofrinho.totalConvertido();
			String ValorTotalConvertidoTexual = String.format("%.2f" , valorTotalConvertido);
		    ValorTotalConvertidoTexual = ValorTotalConvertidoTexual.replace(".", ",");
			System.out.println("O valor total convertido para real? " + ValorTotalConvertidoTexual);
			exibirMenuPrincipal();

			break;
			
		default:
			
			System.out.println("Opção inválida, tente novamente!");
			exibirMenuPrincipal();
			break;
			
		
		
	   }
	}
	private void AdicionarMoedas() {
		System.out.println("Selecione uma Moeda:");
		System.out.println("1 - real:");
		System.out.println("2 - Dolar:");
		System.out.println("3 - Euro:");
		
		int opcaoMoeda = sc.nextInt();
		
		//codigo para escolher o valor
		
		System.out.println("Digite o valor:");
		
		String valorTextualMeoda = sc.next();
		valorTextualMeoda = valorTextualMeoda.replace("," , ".");
		double valorMoeda = Double.valueOf(valorTextualMeoda);
		
		Moeda moeda = null;
		
		// escolha da moeda
		
		
        if (opcaoMoeda == 1){
          moeda = new Real(valorMoeda);
        } else if (opcaoMoeda == 2) {
          moeda = new Dolar(valorMoeda);

        } else if (opcaoMoeda ==3){
          moeda = new Euro(valorMoeda);

        } else {
        	System.out.println("Não existe essa meoda!");
        	exibirMenuPrincipal();
        }		
		
        cofrinho.adicionar(moeda);
    	System.out.println("Moeda adicionada!");

    	

		
	}
	private void RemoverMoedas() {
		System.out.println("Escolha Moeda:");
		System.out.println("1 - real:");
		System.out.println("2 - Dolar:");
		System.out.println("3 - Euro:");
		
		int opcaoMoeda = sc.nextInt();
		
		//codigo para escolher o valor
		
		System.out.println("Digite o valor:");
		
		String valorTextualMeoda = sc.next();
		valorTextualMeoda = valorTextualMeoda.replace("," , ".");
		double valorMoeda = Double.valueOf(valorTextualMeoda);
		
		Moeda moeda = null;
		
		// escolha da moeda
		
		
        if (opcaoMoeda == 1){
          moeda = new Real(valorMoeda);
        } else if (opcaoMoeda == 2) {
          moeda = new Dolar(valorMoeda);

        } else if (opcaoMoeda ==3){
          moeda = new Euro(valorMoeda);

        } else {
        	System.out.println("Não existe essa meoda!");
        	exibirMenuPrincipal();
        }	
        
        boolean removeuMoeda = cofrinho.remover(moeda);
        
        if (removeuMoeda) {
        	System.out.println("Moeda removida com sucesso!");
        } else { System.out.println("Não foi encontrado nenhuma moeda com esse valor!");
        	
        }
        
		
	}

}
