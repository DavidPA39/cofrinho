package Uninter;

public class Euro extends Moeda {

	public Euro(double valor) {
		this.valor = valor;
	}
	
	public void info() {
		System.out.println("Euro - " +valor);

	}

	public double converter() {
		
		return this.valor * 6.31;
	}

	public boolean equals(Object objeto) {
		if (this.getClass() != objeto.getClass()) {
			return false;
			}
			
		Euro objetoDeEuro = (Euro) objeto;
		
		if (this.valor != objetoDeEuro.valor) {
			return false;
		}	
		return true;
	}
}
